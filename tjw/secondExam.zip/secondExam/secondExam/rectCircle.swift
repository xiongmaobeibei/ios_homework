//
//  rectCircle.swift
//  secondExam
//
//  Created by student on 2018/11/28.
//  Copyright © 2018年 tanjingwei. All rights reserved.
//

import UIKit

class rectCircle: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        //把背景色设为透明
        self.backgroundColor = UIColor.clear
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func draw(_ rect: CGRect) {
        let pathRect = CGRect(x: 0, y: 0, width: 40, height: 40)
        let path = UIBezierPath(roundedRect: pathRect, cornerRadius: 10)
//        let path = UIBezierPath(ovalIn: rect)
        path.lineWidth = 2
        UIColor.clear.setFill()
        UIColor.blue.setStroke()
        path.fill()
        path.stroke()
    }

}
