//
//  rectView.swift
//  secondExam
//
//  Created by student on 2018/11/28.
//  Copyright © 2018年 tanjingwei. All rights reserved.
//

import UIKit

class rectView: UIView {

    
    override func draw(_ rect: CGRect) {
        var width = rect.size.width;
        var height = rect.size.height;
        var radius = (width + height) * 0.05;

        let path = UIBezierPath(ovalIn: rect)
        UIColor.red.setFill()
        path.fill()

    }

}
