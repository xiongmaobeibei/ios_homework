//
//  ViewController.swift
//  secondExam
//
//  Created by student on 2018/11/28.
//  Copyright © 2018年 tanjingwei. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var labelCount: UILabel!
    @IBOutlet weak var rectCount: UILabel!
    
    lazy var animator = UIDynamicAnimator(referenceView: self.backView)
    let gravity = UIGravityBehavior()
    let collision = UICollisionBehavior()
    
    lazy var animator2 = UIDynamicAnimator(referenceView: self.backView)
    let gravity2 = UIGravityBehavior()
    let collision2 = UICollisionBehavior()

    
    var countLabel = 0
    var countRect = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        animator.addBehavior(gravity)
        animator.addBehavior(collision)
        collision.translatesReferenceBoundsIntoBoundary = true
        
        animator2.addBehavior(gravity2)
        animator2.addBehavior(collision2)
        collision2.translatesReferenceBoundsIntoBoundary = true
    }

    @IBAction func addLabel(_ sender: Any) {
        let width = Int(backView.bounds.width /
            10)
        let randx = Int(arc4random() % 10) * width
        let label = UILabel(frame: CGRect(x: randx, y: 20, width: width, height: width))
        label.backgroundColor = UIColor.clear
        
        
        let rand = 65+Int(arc4random() % 26)
        let a = Character(UnicodeScalar(rand)!)
        label.text = String(a)
        label.textAlignment = .center
        backView.addSubview(label)
        
        countLabel = countLabel+1
        labelCount.text = String(countLabel)
    
        gravity.addItem(label)
        collision.addItem(label)
    }
    
    
    @IBAction func AddOval(_ sender: Any) {
        
        let height = Int(backView.bounds.height /
            10)
        let randy = Int(arc4random() % 10) * height
        let viewRect = CGRect(x: 20, y: randy, width: height-30, height: height-30)
        let view1 = rectCircle(frame: viewRect)
        backView.addSubview(view1)
        
        
        countRect = countRect+1
        rectCount.text = String(countRect)
        
        gravity2.gravityDirection = CGVector(dx: 1, dy: 0)
        
        gravity2.addItem(view1)
        collision2.addItem(view1)
        
    }
    
    @IBAction func clearAll(_ sender: Any) {
        for item in backView.subviews {
            if item is UILabel {
                item.removeFromSuperview()
                gravity.removeItem(item)
                collision.removeItem(item)
            }
            if item is rectCircle {
                item.removeFromSuperview()
                gravity2.removeItem(item)
                collision2.removeItem(item)
            }
        }
        countRect = 0
        countLabel = 0
        rectCount.text = String(countRect)
        labelCount.text = String(countLabel)
    }
    
    
}

